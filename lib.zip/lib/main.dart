import 'package:flutter/material.dart'; //Trabajo de Checco para evitar errores de compilación y plagio

import 'models/producto.dart';
import 'productos_page.dart';

void main() {
  runApp(const InventarioApp());
}

class InventarioApp extends StatelessWidget {
  const InventarioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MI barrio',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const RegistroProductoPage(),
    );
  }
}

class RegistroProductoPage extends StatefulWidget {
  const RegistroProductoPage({super.key});

  @override
  State<RegistroProductoPage> createState() => _RegistroProductoPageState();
}

class _RegistroProductoPageState extends State<RegistroProductoPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _codigoController = TextEditingController();

  final TextEditingController _nombreController = TextEditingController();

  final TextEditingController _precioController = TextEditingController();

  final List<Producto> _productos = <Producto>[];

  String? _categoria;
  String _estado = 'Disponible';
  double _stock = 0;
  DateTime? _fechaIngreso;
  bool _perecible = false;

  final List<String> _categorias = [
    'Abarrotes',
    'Bebidas',
    'Limpieza',
    'Golosinas',
    'Lácteos',
    'Otro',
  ];

  // ----------------------------------------------------------
  // SELECCIONAR FECHA
  // ----------------------------------------------------------

  Future<void> _seleccionarFecha() async {
    final DateTime hoy = DateTime.now();

    final DateTime? fecha = await showDatePicker(
      context: context,
      initialDate: _fechaIngreso ?? hoy,
      firstDate: DateTime(2000),
      lastDate: hoy,
    );

    if (fecha != null) {
      setState(() {
        _fechaIngreso = fecha;
      });
    }
  }

  // ----------------------------------------------------------
  // REGISTRAR PRODUCTO
  // ----------------------------------------------------------

  void _registrarProducto() {
    // 1. Validar formulario
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // 2. Validar fecha
    if (_fechaIngreso == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Debe seleccionar la fecha de ingreso')),
      );
      return;
    }

    // 3. Obtener precio
    final double? precio = double.tryParse(_precioController.text.trim());

    if (precio == null || precio <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ingrese un precio válido mayor que 0')),
      );
      return;
    }

    // 4. Crear producto
    final Producto nuevoProducto = Producto(
      codigo: _codigoController.text.trim(),
      nombre: _nombreController.text.trim(),
      categoria: _categoria!,
      precio: precio,
      stock: _stock.round(),
      estado: _estado,
      fechaIngreso: _fechaIngreso!,
      perecible: _perecible,
    );

    // 5. Guardar producto en memoria
    setState(() {
      _productos.add(nuevoProducto);
    });

    // 6. Limpiar formulario
    _codigoController.clear();
    _nombreController.clear();
    _precioController.clear();

    setState(() {
      _categoria = null;
      _estado = 'Disponible';
      _stock = 0;
      _fechaIngreso = null;
      _perecible = false;
    });

    // 7. Mostrar mensaje
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Producto registrado correctamente'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  // ----------------------------------------------------------
  // LIBERAR CONTROLADORES
  // ----------------------------------------------------------

  @override
  void dispose() {
    _codigoController.dispose();
    _nombreController.dispose();
    _precioController.dispose();

    super.dispose();
  }

  // ----------------------------------------------------------
  // INTERFAZ
  // ----------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('MI barrio'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Badge(
              label: Text(_productos.length.toString()),
              child: IconButton(
                icon: const Icon(Icons.inventory_2),
                tooltip: 'Ver productos',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          ProductosPage(productos: _productos),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),

      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Registro de producto',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 20),

              // ------------------------------------------------
              // CÓDIGO
              // ------------------------------------------------
              TextFormField(
                controller: _codigoController,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: const InputDecoration(
                  labelText: 'Código del producto',
                  hintText: 'Ejemplo: 100001',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.qr_code),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'El código es obligatorio';
                  }

                  if (!RegExp(r'^\d{6}$').hasMatch(value.trim())) {
                    return 'Debe tener exactamente 6 dígitos';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 16),

              // ------------------------------------------------
              // NOMBRE
              // ------------------------------------------------
              TextFormField(
                controller: _nombreController,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Nombre del producto',
                  hintText: 'Ejemplo: Arroz',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.shopping_bag),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'El nombre es obligatorio';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 16),

              // ------------------------------------------------
              // CATEGORÍA
              // ------------------------------------------------
              DropdownButtonFormField<String>(
                value: _categoria,
                decoration: const InputDecoration(
                  labelText: 'Categoría',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.category),
                ),
                items: _categorias.map((String categoria) {
                  return DropdownMenuItem<String>(
                    value: categoria,
                    child: Text(categoria),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _categoria = value;
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Seleccione una categoría';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 16),

              // ------------------------------------------------
              // PRECIO
              // ------------------------------------------------
              TextFormField(
                controller: _precioController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Precio unitario (S/)',
                  hintText: 'Ejemplo: 15.50',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.attach_money),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'El precio es obligatorio';
                  }

                  final double? precio = double.tryParse(value.trim());

                  if (precio == null) {
                    return 'Ingrese un precio válido';
                  }

                  if (precio <= 0) {
                    return 'El precio debe ser mayor que 0';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 20),

              // ------------------------------------------------
              // STOCK
              // ------------------------------------------------
              Text(
                'Cantidad en stock: ${_stock.round()}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              Slider(
                value: _stock,
                min: 0,
                max: 100,
                divisions: 100,
                label: _stock.round().toString(),
                onChanged: (double value) {
                  setState(() {
                    _stock = value;
                  });
                },
              ),

              const SizedBox(height: 16),

              // ------------------------------------------------
              // ESTADO
              // ------------------------------------------------
              const Text(
                'Estado del producto',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 8),

              SegmentedButton<String>(
                segments: const [
                  ButtonSegment<String>(
                    value: 'Disponible',
                    label: Text('Disponible'),
                    icon: Icon(Icons.check_circle),
                  ),
                  ButtonSegment<String>(
                    value: 'Agotado',
                    label: Text('Agotado'),
                    icon: Icon(Icons.cancel),
                  ),
                ],
                selected: <String>{_estado},
                onSelectionChanged: (Set<String> seleccion) {
                  setState(() {
                    _estado = seleccion.first;
                  });
                },
              ),

              const SizedBox(height: 20),

              // ------------------------------------------------
              // FECHA
              // ------------------------------------------------
              const Text(
                'Fecha de ingreso',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 8),

              OutlinedButton.icon(
                onPressed: _seleccionarFecha,
                icon: const Icon(Icons.calendar_month),
                label: Text(
                  _fechaIngreso == null
                      ? 'Seleccionar fecha'
                      : '${_fechaIngreso!.day.toString().padLeft(2, '0')}/'
                            '${_fechaIngreso!.month.toString().padLeft(2, '0')}/'
                            '${_fechaIngreso!.year}',
                ),
              ),

              if (_fechaIngreso == null)
                const Padding(
                  padding: EdgeInsets.only(top: 5),
                  child: Text(
                    'La fecha de ingreso es obligatoria',
                    style: TextStyle(color: Colors.red, fontSize: 12),
                  ),
                ),

              const SizedBox(height: 16),

              // ------------------------------------------------
              // PERECIBLE
              // ------------------------------------------------
              SwitchListTile(
                title: const Text('¿Producto perecible?'),
                subtitle: Text(_perecible ? 'Sí' : 'No'),
                value: _perecible,
                onChanged: (bool value) {
                  setState(() {
                    _perecible = value;
                  });
                },
              ),

              const SizedBox(height: 20),

              // ------------------------------------------------
              // REGISTRAR PRODUCTO
              // ------------------------------------------------
              FilledButton.icon(
                onPressed: _registrarProducto,
                icon: const Icon(Icons.save),
                label: const Text('Registrar producto'),
              ),

              const SizedBox(height: 12),

              // ------------------------------------------------
              // VER PRODUCTOS
              // ------------------------------------------------
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          ProductosPage(productos: _productos),
                    ),
                  );
                },
                icon: const Icon(Icons.table_chart),
                label: Text('Ver productos (${_productos.length})'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
